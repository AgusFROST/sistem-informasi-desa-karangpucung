<?php $__env->startSection('main'); ?>
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Potensi</h1>
</div>

<a href="<?php echo e(route('potensi.create')); ?>" class="btn btn-primary mb-3">Tambah Potensi</a>

<div class="row">
    <div class="col-lg-8">
        <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
        <?php endif; ?>

        <form action="/dashboard/potensi" method="GET">
            <div class="input-group mb-3 mt-3">
                <input type="search" name="search" class="form-control" placeholder="Cari judul..." value="<?php echo e(request('search')); ?>">
                <button class="btn btn-primary" type="submit">Cari</button>
            </div>
        </form>

        <table class="table table-striped">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Judul</th>
                    <th>Kategori</th>
                    <th>Views</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $potensi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($item->title); ?></td>
                    <td><?php echo e($item->category->name); ?></td>
                    <td><?php echo e($item->views); ?></td>
                    <td>
                        <a href="<?php echo e(route('potensi.edit', $item->slug)); ?>" class="btn btn-warning btn-sm">Edit</a>
                        <form action="<?php echo e(route('potensi.destroy', $item->slug)); ?>" method="POST" class="d-inline">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button class="btn btn-danger btn-sm" onclick="return confirm('Yakin ingin menghapus?')">Hapus</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        <?php echo e($potensi->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\desa-karangpucung\resources\views/dashboard/potensi/index.blade.php ENDPATH**/ ?>