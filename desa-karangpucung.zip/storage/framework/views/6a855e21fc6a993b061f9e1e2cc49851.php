<?php $__env->startSection('main'); ?>
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2"><?php echo e($title); ?></h1>
</div>

<div class="row">
    <div class="col-lg-4">
        <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
        <?php endif; ?>

        <form action="<?php echo e(route('idm.update')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="mb-3">
                <label class="form-label">Status</label>
                <select name="idm_status_id" class="form-select" required>
                    <option value="" disabled <?php echo e(!isset($idm->idm_status_id) ? 'selected' : ''); ?>>Pilih Status</option>
                    <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($status->id); ?>"
                        <?php echo e(isset($idm->idm_status_id) && $idm->idm_status_id == $status->id ? 'selected' : ''); ?>>
                        <?php echo e($status->status); ?>

                    </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>


            <div class="mb-3">
                <label class="form-label">Nilai</label>
                <input type="text" name="nilai" class="form-control"
                    value="<?php echo e(old('nilai', $idm->nilai ?? '0')); ?>" required>
            </div>

            <div class="mb-3">
                <label class="form-label">Tahun</label>
                <input type="number" name="tahun" class="form-control"
                    value="<?php echo e(old('tahun', $idm->tahun ?? date('Y'))); ?>" required>
            </div>

            <button type="submit" class="btn btn-primary">Update</button>
        </form>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\desa-karangpucung\resources\views/dashboard/ui/infografis/idm.blade.php ENDPATH**/ ?>