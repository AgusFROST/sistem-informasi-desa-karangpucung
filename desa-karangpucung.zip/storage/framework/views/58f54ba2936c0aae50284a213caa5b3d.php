<?php $__env->startSection('main'); ?>
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2"><?php echo e($title); ?></h1>
</div>

<?php if(session('success')): ?>
<div class="alert alert-success">
    <?php echo e(session('success')); ?>

</div>
<?php endif; ?>

<form action="/dashboard/ui/footer/media-sosial" method="POST">
    <?php echo csrf_field(); ?>
    <div class="row row-cols-1 row-cols-md-3 g-4">
        <?php $__currentLoopData = $MediaSosial; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $media): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title"><?php echo e($media->name); ?></h5>

                    <div class="mb-2">
                        <label for="url_<?php echo e($media->id); ?>" class="form-label">URL</label>
                        <input type="url" class="form-control" id="url_<?php echo e($media->id); ?>"
                            name="MediaSosial[<?php echo e($media->id); ?>][url]" value="<?php echo e($media->url); ?>">
                    </div>

                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <button type="submit" class="btn btn-primary mt-3">Update</button>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\desa-karangpucung\resources\views/dashboard/ui/footer/media-sosial.blade.php ENDPATH**/ ?>