<?php $__env->startSection('main'); ?>

<?php echo $__env->make('partials.frontend.menuInfografis', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<section id="idm" class="idm mt-5 mb-4">
    <div class="row">
        <div class="col-lg-6">
            <h2 class="h1 text-danger fw-bold text-uppercase">IDM</h2>
            <p class="lead">
                Indeks Desa Membangun (IDM) merupakan indeks komposit yang dibentuk dari tiga indeks, yaitu Indeks Ketahanan Sosial, Indeks Ketahanan Ekonomi, dan Indeks Ketahanan Ekologi/Lingkungan.
            </p>
        </div>
        <div class="col-lg-6">
            <div class="row row-cols-1 row-cols-md-1 g-4">
                <div class="col">
                    <div class="card mb-3">
                        <div class="row g-0">
                            <div class="col-md-6 px-4 py-2">
                                <h5 class="fw-bold">SKOR IDM <?php echo e($idm->tahun); ?></h5>
                            </div>
                            <div class="col-md-6">
                                <div class="card-body text-end">
                                    <p class="fw-bold fs-1"><?php echo e($idm->nilai); ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col">
                    <div class="card mb-3">
                        <div class="row g-0">
                            <div class="col-md-6 px-4 py-2">
                                <h5 class="fw-bold">STATUS IDM <?php echo e($idm->tahun); ?></h5>
                            </div>
                            <div class="col-md-6">
                                <div class="card-body text-end">
                                    <!-- Tampilkan status IDM dengan relasi -->
                                    <p class="fw-bold fs-1"><?php echo e($idm->idmStatus->status); ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\desa-karangpucung\resources\views/infografis/idm.blade.php ENDPATH**/ ?>