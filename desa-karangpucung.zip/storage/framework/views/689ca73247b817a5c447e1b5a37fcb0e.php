<?xml version="1.0" encoding="UTF-8" ?>
<rss version="2.0">
    <channel>
        <title>Website Resmi Desa Karangpucung</title>
        <link><?php echo e(url('/')); ?></link>
        <description>RSS feed for my blog</description>

        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <item>
            <title><?php echo e($post->title); ?></title>
            <link><?php echo e(url('berita/' . $post->slug)); ?></link>
            <description><?php echo e(Str::limit($post->context, 150)); ?></description>
            <pubDate><?php echo e($post->created_at->toRssString()); ?></pubDate>
            <guid><?php echo e(url('berita/' . $post->slug)); ?></guid>
        </item>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </channel>
</rss><?php /**PATH E:\laragon\www\desa-karangpucung\resources\views/rss.blade.php ENDPATH**/ ?>