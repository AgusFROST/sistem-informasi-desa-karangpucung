<?php $__env->startSection('main'); ?>
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2"><?php echo e($title); ?></h1>
</div>

<div class="row">
    <div class="col-lg-8">
        <form action="/dashboard/ui/pelayanan/<?php echo e($pelayanan->slug); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="mb-3">
                <label class="form-label">Nama</label>
                <input type="text" name="name" class="form-control" value="<?php echo e($pelayanan->name); ?>">
            </div>
            <div class="mb-3">
                <label class="form-label">Deskripsi</label>
                <input id="body" type="hidden" name="body" value="<?php echo e($pelayanan->body); ?>">
                <trix-editor input="body"></trix-editor>
            </div>

            <a href="/dashboard/ui/pelayanan" class="btn btn-secondary">Back</a>
            <button type="submit" class="btn btn-primary">Update</button>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\desa-karangpucung\resources\views/dashboard/ui/Pelayanan/edit.blade.php ENDPATH**/ ?>