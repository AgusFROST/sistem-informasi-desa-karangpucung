<?php $__env->startSection('main'); ?>
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2"><?php echo e($title); ?></h1>
</div>

<div class="row">
    <div class="col-lg-8">
        <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
        <?php endif; ?>

        <form action="<?php echo e(url('/dashboard/ui/struktur-organisasi')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="row row-cols-1 row-cols-md-2 g-4">
                <div class="col">
                    <div class="card">
                        <img id="previewPemdes"
                            src="<?php echo e($struktur && $struktur->pemdes ? asset('storage/' . $struktur->pemdes) : ''); ?>"
                            class="img-fluid mb-2"
                            style="display: <?php echo e($struktur && $struktur->pemdes ? 'block' : 'none'); ?>;">
                        <div class="card-body">
                            <h5 class="card-title">Struktur Organisasi Pemerintahan Desa</h5>
                            <div class="mb-3">
                                <label for="pemdes" class="form-label">Pilih Gambar</label>

                                <input type="file" class="form-control" id="pemdes" name="pemdes"
                                    onchange="previewImage(event, 'previewPemdes')">
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col">
                    <div class="card">
                        <img id="previewBpd"
                            src="<?php echo e($struktur && $struktur->bpd ? asset('storage/' . $struktur->bpd) : ''); ?>"
                            class="img-fluid mb-2"
                            style="display: <?php echo e($struktur && $struktur->bpd ? 'block' : 'none'); ?>;">
                        <div class="card-body">
                            <h5 class="card-title">Struktur Organisasi Badan Permusyawaratan Desa</h5>
                            <div class="mb-3">
                                <label for="bpd" class="form-label">Pilih Gambar</label>

                                <input type="file" class="form-control" id="bpd" name="bpd"
                                    onchange="previewImage(event, 'previewBpd')">
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <button type="submit" class="btn btn-primary mt-3">Update</button>
        </form>
    </div>
</div>

<script>
    function previewImage(event, previewId) {
        const input = event.target;
        const preview = document.getElementById(previewId);
        if (input.files && input.files[0]) {
            const reader = new FileReader();
            reader.onload = function(e) {
                preview.src = e.target.result;
                preview.style.display = 'block';
            }
            reader.readAsDataURL(input.files[0]);
        }
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\desa-karangpucung\resources\views/dashboard/ui/struktur-organisasi.blade.php ENDPATH**/ ?>