<?php $__env->startSection('main'); ?>
<section id="pelayanan" class="pelayanan">
    <h1 class="text-danger mt-4 fw-bold">Pelayanan Desa</h1>
    <p class="fs-5">Informasi mengenai berbagai layanan yang tersedia di Desa Karangpucung.</p>

    <div class="row">
        <?php $__currentLoopData = $pelayanans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pelayanan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-4 mb-3">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title"><?php echo e($pelayanan->name); ?></h5>
                    <p class="card-text"><?php echo e(Str::limit(strip_tags($pelayanan->body), 100)); ?></p>
                    <a href="/pelayanan-desa/<?php echo e($pelayanan->slug); ?>" class="btn btn-primary">Lihat Detail</a>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\desa-karangpucung\resources\views/pelayanan/services.blade.php ENDPATH**/ ?>