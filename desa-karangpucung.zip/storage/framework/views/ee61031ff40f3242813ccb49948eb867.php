<?php $__env->startSection('main'); ?>
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Edit Anggota <?php echo e($struktur->name); ?></h1>
</div>

<div class="row">
    <div class="col-8">
        <form action="<?php echo e(route('organisasi.update', [$struktur->slug, $organisasi->id])); ?>" method="POST"
            enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div class="mb-3">
                <label for="nama" class="form-label">Nama</label>
                <input type="text" class="form-control" id="nama" name="nama" value="<?php echo e($organisasi->nama); ?>" required>
            </div>

            <div class="mb-3">
                <label for="jabatan" class="form-label">Jabatan</label>
                <input type="text" class="form-control" id="jabatan" name="jabatan" value="<?php echo e($organisasi->jabatan); ?>"
                    required>
            </div>

            <div class="mb-3">
                <label for="img" class="form-label">Foto</label>
                <input type="file" class="form-control" id="img" name="img" accept="image/*"
                    onchange="previewImage(event)">

                <?php if($organisasi->img): ?>
                <p class="mt-2">Foto saat ini:</p>
                <img src="<?php echo e(asset('storage/'.$organisasi->img)); ?>" width="100" id="currentImage">
                <?php endif; ?>
            </div>

            <div class="mb-3">
                <img id="imagePreview" src="#" class="img-thumbnail d-none" style="max-width: 200px;">
            </div>

            <button type="submit" class="btn btn-primary">Update</button>
            <a href="<?php echo e(route('organisasi.index', $struktur->slug)); ?>" class="btn btn-secondary">Kembali</a>
        </form>
    </div>
</div>

<script>
    function previewImage(event) {
    const input = event.target;
    const preview = document.getElementById('imagePreview');
    const currentImage = document.getElementById('currentImage');

    if (input.files && input.files[0]) {
        const reader = new FileReader();
        reader.onload = function (e) {
            preview.src = e.target.result;
            preview.classList.remove('d-none');

            if (currentImage) {
                currentImage.style.display = 'none'; // Sembunyikan foto lama
            }
        }
        reader.readAsDataURL(input.files[0]);
    }
}
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\desa-karangpucung\resources\views/dashboard/ui/struktur-organisasi/organisasi/edit.blade.php ENDPATH**/ ?>