<?php $__env->startSection('main'); ?>
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2"><?php echo e($title); ?></h1>
</div>

<div class="row">
    <div class="col-lg-8">
        <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
        <?php endif; ?>

        <form method="POST" action="<?php echo e(url('/dashboard/ui/visi-misi')); ?>">
            <?php echo csrf_field(); ?>
            <div class="form-group mb-3">
                <label for="visi">Visi</label>
                <input id="visi" type="hidden" name="visi" value="<?php echo e(old('visi', $visiMisi ? $visiMisi->visi : '')); ?>"
                    required>
                <!-- Trix Editor -->
                <trix-editor input="visi" class="<?php $__errorArgs = ['visi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"></trix-editor>
            </div>

            <div class="form-group mb-3">
                <label for="misi">Misi</label>
                <input id="misi" type="hidden" name="misi" value="<?php echo e(old('misi', $visiMisi ? $visiMisi->misi : '')); ?>"
                    required>
                <!-- Trix Editor -->
                <trix-editor input="misi" class="<?php $__errorArgs = ['misi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"></trix-editor>
            </div>

            <button type="submit" class="btn btn-primary mb-4">Update</button>
        </form>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\desa-karangpucung\resources\views/dashboard/ui/visi-misi.blade.php ENDPATH**/ ?>