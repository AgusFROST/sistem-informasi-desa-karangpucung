<?php $__env->startSection('main'); ?>
<section id="peraturan" class="peraturan mb-5">
    <h1 class="text-danger mt-4 fw-bold">Peraturan Desa</h1>
    <p class="fs-5">Informasi mengenai berbagai peraturan yang berlaku di Desa Karangpucung.</p>

    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="mb-4">
        <h3 class="fw-bold"><?php echo e($category->name); ?></h3>

        <?php if($category->rules->count() > 0): ?>
        <div class="row">
            <?php $__currentLoopData = $category->rules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4 mb-3">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo e($rule->name); ?></h5>
                        <p class="card-text"><?php echo e(Str::limit(strip_tags($rule->body), 50)); ?></p>
                        <a href="<?php echo e(url('/peraturan/' . $rule->slug)); ?>" class="btn btn-primary">Lihat Detail</a>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php else: ?>
        <p class="text-muted">Belum ada aturan dalam kategori ini.</p>
        <?php endif; ?>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\desa-karangpucung\resources\views/peraturan/rules.blade.php ENDPATH**/ ?>