<?php $__env->startSection('main'); ?>
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2"><?php echo e($title); ?></h1>
</div>

<a href="/dashboard/ui/carausel/create" class="btn btn-primary mb-3">Add Carausel</a>

<div class="row">
    <div class="col-lg-8">
        <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
        <?php endif; ?>

        <table class="table">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Image</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $carausels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $carausel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><img src="<?php echo e(asset('storage/'.$carausel->img)); ?>" alt="Carausel" width="100"></td>
                    <td>
                        <a href="/dashboard/ui/carausel/<?php echo e($carausel->id); ?>/edit"
                            class="btn btn-warning btn-sm">Edit</a>
                        <form action="/dashboard/ui/carausel/<?php echo e($carausel->id); ?>" method="POST" class="d-inline">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button class="btn btn-danger btn-sm"
                                onclick="return confirm('Are you sure?')">Delete</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\desa-karangpucung\resources\views/dashboard/ui/carausel/index.blade.php ENDPATH**/ ?>