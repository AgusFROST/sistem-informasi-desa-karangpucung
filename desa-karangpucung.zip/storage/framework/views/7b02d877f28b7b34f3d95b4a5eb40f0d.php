<?php $__env->startSection('main'); ?>
<section class="preview-pdf">
    <h2><?php echo e($sedes->name); ?></h2>
    <iframe src="<?php echo e(asset('storage/' . $sedes->arsip)); ?>" width="100%" height="600px" style="border: none;"></iframe>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\desa-karangpucung\resources\views/preview-pdf.blade.php ENDPATH**/ ?>