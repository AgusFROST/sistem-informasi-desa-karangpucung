<?php $__env->startSection('main'); ?>
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2"><?php echo e($title); ?></h1>
</div>

<?php if(session('success')): ?>
<div class="alert alert-success">
    <?php echo e(session('success')); ?>

</div>
<?php endif; ?>

<form action="<?php echo e(url('/dashboard/ui/administrasi-penduduk/agama')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <div class="row row-cols-1 row-cols-md-3 g-4">
        <?php $__currentLoopData = $agamas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agama): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col">
            <div class="card h-100">
                <div class="card-body">
                    <h5 class="card-title"><?php echo e($agama->name); ?></h5>
                    <input type="hidden" name="agama[<?php echo e($loop->index); ?>][id]" value="<?php echo e($agama->id); ?>">
                    <input type="number" name="agama[<?php echo e($loop->index); ?>][jumlah]" value="<?php echo e($agama->jumlah); ?>" class="form-control">
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <button type="submit" class="btn btn-primary mt-5 mb-5">Update</button>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\desa-karangpucung\resources\views/dashboard/ui/infografis/admPenduduk/agama.blade.php ENDPATH**/ ?>