<?php $__env->startSection('main'); ?>
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2"><?php echo e($title); ?></h1>
</div>

<!-- Menampilkan Pesan Sukses -->
<?php if(session('success')): ?>
<div class="alert alert-success">
    <?php echo e(session('success')); ?>

</div>
<?php endif; ?>

<!-- Form untuk mengupdate data pendidikan -->
<form action="<?php echo e(url('/dashboard/ui/administrasi-penduduk/pendidikan')); ?>" method="POST">
    <?php echo csrf_field(); ?>

    <div class="row row-cols-1 row-cols-md-3 g-4">
        <?php $__currentLoopData = $pendidikan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col">
            <div class="card h-100">
                <div class="card-body">
                    <h5 class="card-title"><?php echo e($item->name); ?></h5>
                    <div class="mb-3">
                        <label for="jumlah-<?php echo e($item->id); ?>" class="form-label">Jumlah</label>
                        <input type="number" id="jumlah-<?php echo e($item->id); ?>" name="jumlah[<?php echo e($item->id); ?>]" class="form-control" value="<?php echo e($item->jumlah); ?>" required>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <button type="submit" class="btn btn-primary mt-3">Update</button>
</form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\desa-karangpucung\resources\views/dashboard/ui/infografis/admPenduduk/pendidikan.blade.php ENDPATH**/ ?>