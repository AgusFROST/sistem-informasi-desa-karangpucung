<?php $__env->startSection('main'); ?>
<section id="potensi" class="potensi-desa mt-5 mb-5">
    <h1 class="text-danger mt-4 fw-bold"><?php echo e($category->name); ?></h1>
    <p class="fs-5">Menampilkan semua potensi untuk kategori <?php echo e($category->name); ?></p>

    <!-- Content -->
    <?php if($potensis->count()): ?>
    <div class="row row-cols-1 row-cols-md-3 g-4 mb-5">
        <?php $__currentLoopData = $potensis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col">
            <div class="card h-100">
                <img src="<?php echo e(asset('storage/' . $post->img)); ?>" class="card-img-top" alt="<?php echo e($post->title); ?>">
                <div class="card-body">
                    <h5 class="card-title"><?php echo e($post->title); ?></h5>
                    <p class="card-text"><?php echo e(Str::limit($post->excerpt, 100)); ?></p>
                    <a href="/potensi-desa/<?php echo e($post->slug); ?>" class="btn btn-primary">Baca Selengkapnya</a>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php echo e($potensis->links()); ?>

    <!-- Pagination -->
    <?php else: ?>
    <p class="text-center">Belum ada potensi untuk kategori ini.</p>
    <?php endif; ?>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\desa-karangpucung\resources\views/category.blade.php ENDPATH**/ ?>