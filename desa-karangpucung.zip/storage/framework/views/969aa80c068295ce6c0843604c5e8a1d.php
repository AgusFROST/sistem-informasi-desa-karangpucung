<?php $__env->startSection('main'); ?>
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Sejarah Desa</h1>
</div>

<a href="<?php echo e(route('sejarah-desa.create')); ?>" class="btn btn-primary mb-3">Tambah Sejarah Desa</a>

<div class="row">
    <div class="col-lg-6">
        <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
        <?php endif; ?>

        <div class="table-responsive">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Arsip</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $sejarahDesa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sejarah): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($sejarah->name); ?></td>
                        <td><a href="<?php echo e(Storage::url($sejarah->arsip)); ?>" target="_blank">Lihat Arsip</a></td>
                        <td>
                            <a href="<?php echo e(route('sejarah-desa.edit', $sejarah->slug)); ?>"
                                class="btn btn-warning btn-sm">Edit</a>
                            <form action="<?php echo e(route('sejarah-desa.destroy', $sejarah->slug)); ?>" method="POST"
                                style="display:inline;"
                                onsubmit="return confirm('Apakah Anda yakin ingin menghapus item ini?');">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger btn-sm">Hapus</button>
                            </form>
                        </td>

                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\desa-karangpucung\resources\views/dashboard/ui/sejarahDesa/sejarah-desa.blade.php ENDPATH**/ ?>