<?php $__env->startSection('main'); ?>
<section id="potensi" class="potensi mt-5 mb-5">
    <h1 class="text-danger mt-4 fw-bold">Potensi Desa</h1>
    <p class="fs-5">Informasi tentang potensi dan kemajuan Desa di berbagai bidang seperti ekonomi, pariwisata,
        pertanian, industri kreatif, dan kelestarian lingkungan</p>

    <!-- Content -->

    <div class="row row-cols-1 row-cols-md-3 g-4 mb-5">
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ctr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col">
            <div class="text-center">
                <a href="/potensi-desa?category=<?php echo e($ctr->slug); ?>" class="fw-bold text-dark">
                    <img src="<?php echo e(asset('storage/' . $ctr->img)); ?>" class="img-fluid rounded-pill mb-2"
                        alt="<?php echo e($ctr->name); ?>">
                </a>
                <a href="/potensi-desa?category=<?php echo e($ctr->slug); ?>" class="fw-bold text-dark">
                    <h3><?php echo e($ctr->name); ?></h3>
                </a>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <div class="text-center">
        <?php echo e($categories->links()); ?>

    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\desa-karangpucung\resources\views/categories.blade.php ENDPATH**/ ?>