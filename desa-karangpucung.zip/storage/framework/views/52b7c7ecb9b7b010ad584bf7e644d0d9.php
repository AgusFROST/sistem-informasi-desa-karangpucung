<?php $__env->startSection('main'); ?>
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2"><?php echo e($title); ?></h1>
</div>

<?php if(session('success')): ?>
<div class="alert alert-success"><?php echo e(session('success')); ?></div>
<?php endif; ?>

<form method="POST" action="<?php echo e(url('/dashboard/ui/administrasi-penduduk/umur')); ?>">
    <?php echo csrf_field(); ?>

    <div class="row row-cols-2 row-cols-md-4 g-4 mb-4">
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col">
            <div class="card">

                <div class="card-body">
                    <h5 class="card-title">Rentang Usia <?php echo e($row->gender->jenis_kelamin); ?> : <?php echo e($row->rentangUmur->usia); ?></h5>
                    <input type="number" name="jumlah[<?php echo e($row->id); ?>]" value="<?php echo e($row->jumlah); ?>" class="form-control">
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <button type="submit" class="btn btn-primary mb-4">Update</button>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\desa-karangpucung\resources\views/dashboard/ui/infografis/admPenduduk/umur.blade.php ENDPATH**/ ?>