<?php $__env->startSection('main'); ?>

<?php echo $__env->make('partials.frontend.menuInfografis', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<section id="bansos" class="bansos mt-5">
    <h2 class="h1 text-danger fw-bold text-uppercase">Jumlah Penerima Bansos</h2>
    <table class="table table-bordered">
        <thead class="table-success">
            <tr>
                <th>PENERIMA BANTUAN SOSIAL</th>
                <th>JUMLAH</th>
                <th>%</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $bansos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($item->nama_bansos); ?></td>
                <td><?php echo e(number_format($item->jumlah)); ?> Keluarga</td>
                <td><?php echo e($total > 0 ? number_format(($item->jumlah / $total) * 100, 2) : 0); ?> %</td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        <tfoot class="table-success">
            <tr>
                <th colspan="1" class="text-center">TOTAL PENERIMA BANTUAN SOSIAL</th>
                <th><?php echo e(number_format($total)); ?> Keluarga</th>
                <th>100 %</th>
            </tr>
        </tfoot>
    </table>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\desa-karangpucung\resources\views/infografis/bansos.blade.php ENDPATH**/ ?>