<?php $__env->startSection('main'); ?>
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2"><?php echo e($title); ?></h1>
</div>

<?php if(session('success')): ?>
<div class="alert alert-success"><?php echo e(session('success')); ?></div>
<?php endif; ?>

<form action="<?php echo e(url('/dashboard/ui/administrasi-penduduk/pekerjaan')); ?>" method="POST">
    <?php echo csrf_field(); ?>

    <div class="row row-cols-2 row-cols-md-4 g-4">
        <?php $__currentLoopData = $pekerjaan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title"><?php echo e($p->name); ?></h5>
                    <input type="hidden" name="pekerjaan[<?php echo e($index); ?>][id]" value="<?php echo e($p->id); ?>">
                    <input type="number" name="pekerjaan[<?php echo e($index); ?>][jumlah]" value="<?php echo e($p->jumlah); ?>" class="form-control" required>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <button type="submit" class="btn btn-primary mt-4 mb-4">Update</button>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\desa-karangpucung\resources\views/dashboard/ui/infografis/admPenduduk/pekerjaan.blade.php ENDPATH**/ ?>