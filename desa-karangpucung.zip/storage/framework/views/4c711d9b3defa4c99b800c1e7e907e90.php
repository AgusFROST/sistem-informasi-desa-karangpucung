<?php $__env->startSection('main'); ?>
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2"><?php echo e($title); ?></h1>
</div>

<form action="/dashboard/ui/carausel/<?php echo e($carausel->id); ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>

    <div class="row">
        <div class="col-lg-6">
            <div class="mb-3">
                <label for="img" class="form-label">Image</label>
                <br>
                <img id="imgPreview" src="<?php echo e(asset('storage/'.$carausel->img)); ?>" alt="Carausel" class="mb-2 img-fluid"
                    width="500">
                <?php $__errorArgs = ['img'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <input type="file" name="img" id="img" class="form-control" onchange="previewImage()">
            </div>
            <button type="button" class="btn btn-secondary" onclick="window.location.href='/dashboard/ui/carausel'">
                Kembali
            </button>
            <button class="btn btn-primary">Update</button>
        </div>
    </div>
</form>

<script>
    function previewImage() {
        const img = document.querySelector("#img");
        const imgPreview = document.querySelector("#imgPreview");

        if (img.files && img.files[0]) {
            let reader = new FileReader();
            reader.onload = function(e) {
                imgPreview.src = e.target.result;
            };
            reader.readAsDataURL(img.files[0]);
        }
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\desa-karangpucung\resources\views/dashboard/ui/carausel/edit.blade.php ENDPATH**/ ?>