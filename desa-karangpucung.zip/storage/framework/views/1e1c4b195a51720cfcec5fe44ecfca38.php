<?php $__env->startSection('main'); ?>
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Edit Aturan</h1>
</div>

<div class="row">
    <div class="col-lg-6">
        <form action="<?php echo e(url('/dashboard/ui/peraturan/' . $categorySlug . '/' . $rule->slug)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="mb-3">
                <label for="name" class="form-label">Nama Aturan</label>
                <input type="text" class="form-control" id="name" name="name" required
                    value="<?php echo e(old('name', $rule->name)); ?>">
            </div>

            <div class="mb-3">
                <label for="body" class="form-label">Isi Aturan</label>
                <input id="body" type="hidden" name="body" value="<?php echo e(old('body', $rule->body)); ?>">
                <trix-editor input="body"></trix-editor>
            </div>

            <button type="submit" class="btn btn-primary">Update</button>
            <a href="<?php echo e(url('/dashboard/ui/peraturan/' . $categorySlug)); ?>" class="btn btn-secondary">Kembali</a>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\desa-karangpucung\resources\views/dashboard/ui/peraturan/aturan/edit.blade.php ENDPATH**/ ?>