<?php $__env->startSection('main'); ?>
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2"><?php echo e($title); ?></h1>
</div>

<?php if(session('success')): ?>
<div class="alert alert-success">
    <?php echo e(session('success')); ?>

</div>
<?php endif; ?>

<form action="/dashboard/ui/icon" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div class="mb-3">
        <label for="img" class="form-label">Upload Icon</label>
        <input type="file" class="form-control <?php $__errorArgs = ['img'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="img" name="img"
            onchange="previewImage()">
        <?php $__errorArgs = ['img'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="invalid-feedback"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <!-- Preview Gambar -->
    <div class="mb-3">
        <label class="form-label">Preview:</label>
        <img id="img-preview" class="img-thumbnail" width="200" style="display: none;" alt="Image Preview">
    </div>

    <button type="submit" class="btn btn-primary">Update Icon</button>
</form>

<?php if($icon && $icon->img): ?>
<div class="mb-4">
    <h3 class="mt-4">Icon:</h3>
    <img src="<?php echo e(asset('storage/' . $icon->img)); ?>" alt="Current Icon" class="img-thumbnail" width="200">
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    function previewImage() {
        const fileInput = document.querySelector('#img');
        const imgPreview = document.querySelector('#img-preview');

        const file = fileInput.files[0];
        if (file) {
            const reader = new FileReader();

            reader.onload = function(e) {
                imgPreview.style.display = 'block'; // Tampilkan preview
                imgPreview.src = e.target.result; // Set gambar dari file input
            };

            reader.readAsDataURL(file);
        } else {
            imgPreview.style.display = 'none'; // Sembunyikan jika tidak ada file
        }
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\desa-karangpucung\resources\views/dashboard/ui/icon.blade.php ENDPATH**/ ?>